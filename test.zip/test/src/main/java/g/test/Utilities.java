package g.test;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;


public class Utilities extends Locators {
	  static WebDriver driver;
	  static WebDriverWait  wait;
	  
		@BeforeMethod(alwaysRun = true)
		public static void Setup() {
			 
			System.out.println("here");
			 System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
		     driver= new ChromeDriver();
		     driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		     wait = new WebDriverWait(driver,30);
			 driver.get("https://www.demoblaze.com/index.html");
			 driver.manage().window().maximize();
			 
			
			
		}
		@AfterMethod(alwaysRun = true)
		public static void tearDown() {
			driver.quit();
		}
		
public static void click(String element) throws InterruptedException {
			
			driver.findElement(By.xpath(element)).click();
			
			
		}
public static void Wait(String element) {
	wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(element)));
	
}
public static void alert() throws InterruptedException {
	Thread.sleep(4000);
	driver.switchTo().alert().accept();
}
public static void input(String element, String value) throws InterruptedException {
	
	driver.findElement(By.xpath(element)).sendKeys(value);
	
}
public static void screenshot() throws IOException, InterruptedException {
	Thread.sleep(3000);
	File file = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	FileHandler.copy(file, new File(System.getProperty("user.dir")+"./Screen.png"));
}
}
