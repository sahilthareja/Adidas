package g.test;

import java.io.IOException;

import org.testng.annotations.Test;

public class WebAutomation extends Utilities {

	
	@Test
	public static void SeleniumTest1() throws InterruptedException {
		 
		Wait(phones);
		click(phones);
		Wait(Laptops);
		click(Laptops);
		Wait(Monitors);
		click(Monitors);
		
		
	}
	@Test
	public static void SeleniumTest2() throws InterruptedException {
		 
		
		Wait(Laptops);
		click(Laptops);
		Wait(Sony);
		click(Sony);
		Wait(cart);
		click(cart);
		Thread.sleep(4000);
		driver.switchTo().alert().accept();
		
		
	}
	@Test
	public static void SeleniumTest3() throws InterruptedException, IOException {
		 
		
		Wait(Laptops);
		click(Laptops);
		Wait(dell);
		click(dell);
		Wait(cart);
		click(cart);
		alert();
		Wait(FinalCart);
		click(FinalCart);
		Wait(Delete);
		click(Delete);
		click(PLACEOrder);
		input(name,"Sahil");
		input(country,"India");
		input(city,"chandigarh");
		input(card,"123");
		input(month,"Oct");
		input(year,"covid 2020");
		Wait(Purchase);
		click(Purchase);
		screenshot();
		
		
		
		
	}
	
}

