package g.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class API 

{
	public static String GET="https://petstore.swagger.io/v2/pet/findByStatus?status=available";
	public static String POSTCALL="https://petstore.swagger.io/v2/pet";
	static String JSON="{\"id\":0,\"category\":{\"id\":0,\"name\":\"string\"},\"name\":\"doggie\",\"photoUrls\":[\"string\"],\"tags\":[{\"id\":0,\"name\":\"string\"}],\"status\":\"available\"}";
    static String JSONForUpdate="{\"id\":0,\"category\":{\"id\":0,\"name\":\"string\"},\"name\":\"doggie\",\"photoUrls\":[\"string\"],\"tags\":[{\"id\":0,\"name\":\"string\"}],\"status\":\"sold\"}";
 
    @Test
  public static  void petSatus() {
  	  Response response = null;
  	  try {
  	   response = RestAssured.given()
  	    .when()
  	    .get(GET);
  	  } catch (Exception e) {
  	   e.printStackTrace();
  	  }
  	ResponseBody body =	response.body();
 	 System.out.println(body.asString());
   	 Assert.assertEquals( response.getStatusCode(),200,"InCorrect status code returned");
  	 }
    
    
    
  	@Test
  	public void postPet() {
  		
  		 Response response = null;

  	  	  try {
  	  	   response = RestAssured.given()
  	  	    .when().contentType(ContentType.JSON).body(JSON)
  	  	    .post(POSTCALL);
  	  	  } catch (Exception e) {
  	  	   e.printStackTrace();
  	  	  }
  	  	  
  	  	ResponseBody body =	response.body();
	  	 System.out.println(body.asString());
		
  		 Assert.assertEquals( response.getStatusCode(),200,"InCorrect status code returned");
  	}
  	@Test
  	public void soldPet() {
  		
  		 Response response = null;

  	  	  try {
  	  	   response = RestAssured.given()
  	  	    .when().contentType(ContentType.JSON).body(JSONForUpdate)
  	  	    .put(POSTCALL);
  	  	  } catch (Exception e) {
  	  	   e.printStackTrace();
  	  	  }
  	  	  ResponseBody body =	response.body();
  	  	  System.out.println(body.print());
  		 Assert.assertEquals( response.getStatusCode(),200,"InCorrect status code returned");
  	}
        
    }

