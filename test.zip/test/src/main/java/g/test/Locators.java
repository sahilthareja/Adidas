package g.test;

public class Locators  {
	
	public static String phones ="//a[contains(.,'Phones')]";
	public static String Laptops ="//a[contains(.,'Laptops')]";
	public static String Monitors ="//a[contains(.,'Monitors')]";
	public static String Sony ="//a[contains(.,'Sony vaio i5')]";
	public static String cart ="//a[contains(.,'Add to cart')]";
	public static String dell ="//a[contains(.,'Dell i7 8gb')]";
	public static String FinalCart ="//a[contains(.,'Cart')]";
	public static String Delete ="//a[contains(.,'Delete')]";
	public static String PLACEOrder ="//button[contains(.,'Place Order')]";
	
	public static String name ="//input[@id='name']";
	public static String country ="//input[@id='country']";
	public static String city ="//input[@id='city']";
	public static String card ="//input[@id='card']";
	public static String month ="//input[@id='month']";
	public static String year ="//input[@id='year']";
	public static String alert ="//div[@class='sweet-alert  showSweetAlert visible']";
	public static String Purchase ="//button[contains(.,'Purchase')]";
	
	

	
	

}
